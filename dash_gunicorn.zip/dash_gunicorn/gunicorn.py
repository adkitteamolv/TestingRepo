# -*- coding: utf-8 -*-
bind = "0.0.0.0:8050"
reload = True
capture_output = True
loglevel = "debug"
timeout = 600
